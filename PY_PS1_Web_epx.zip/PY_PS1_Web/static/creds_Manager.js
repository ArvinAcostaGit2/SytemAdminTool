// ============================================================================
// INDEXEDDB CREDENTIAL MANAGER
// Client-side credential storage and management system
// ============================================================================

const CredentialManager = {
    dbName: 'ADUserSearchDB',
    storeName: 'credentials',
    db: null,

    // Initialize IndexedDB
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, 1);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    const objectStore = db.createObjectStore(this.storeName, { 
                        keyPath: 'id', 
                        autoIncrement: true 
                    });
                    objectStore.createIndex('Program', 'Program', { unique: false });
                }
            };
        });
    },

    // Get all credentials from IndexedDB
    async getAll() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readonly');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.getAll();

            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    },

    // Add a new credential
    async add(credential) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.add(credential);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    },

    // Update existing credential
    async update(credential) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.put(credential);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    },

    // Delete a credential by ID
    async delete(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.delete(id);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    },

    // Clear all credentials
    async clearAll() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.clear();

            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    },

    // Check if credentials exist
    async hasCredentials() {
        const creds = await this.getAll();
        return creds && creds.length > 0;
    },

    // Initialize credentials from template (creds.js)
    async initializeFromTemplate(templateData) {
        const promises = templateData.map(cred => this.add(cred));
        return Promise.all(promises);
    }
};

// ============================================================================
// UI MANAGEMENT
// ============================================================================

const CredentialUI = {
    currentEditId: null,

    // Show initial setup modal
    showInitialSetupModal() {
        const modal = new bootstrap.Modal(document.getElementById('credentialSetupModal'));
        document.getElementById('setupModalTitle').textContent = 'Initial Credential Setup';
        document.getElementById('setupInstructions').style.display = 'block';
        this.clearSetupForm();
        modal.show();
    },

    // Show add credential modal
    showAddCredentialModal() {
        const modal = new bootstrap.Modal(document.getElementById('credentialSetupModal'));
        document.getElementById('setupModalTitle').textContent = 'Add New Credential';
        document.getElementById('setupInstructions').style.display = 'none';
        this.clearSetupForm();
        modal.show();
    },

    // Clear setup form
    clearSetupForm() {
        document.getElementById('setupProgram').value = '';
        document.getElementById('setupDCIP').value = '';
        document.getElementById('setupUsername').value = '';
        document.getElementById('setupPassword').value = '';
        this.currentEditId = null;
    },

    // Save credential from setup modal
    async saveCredential() {
        const program = document.getElementById('setupProgram').value.trim();
        const dcIP = document.getElementById('setupDCIP').value.trim();
        const username = document.getElementById('setupUsername').value.trim();
        const password = document.getElementById('setupPassword').value;

        if (!program || !dcIP || !username) {
            alert('Please fill in Program, Domain Controller IP, and Domain Username');
            return;
        }

        const credential = {
            Program: program,
            DomainControllerIP: dcIP,
            DomainUsername: username,
            DomainPassword: password
        };

        try {
            if (this.currentEditId) {
                // Update existing
                credential.id = this.currentEditId;
                await CredentialManager.update(credential);
                this.showToast('Credential updated successfully!', 'success');
            } else {
                // Add new
                await CredentialManager.add(credential);
                this.showToast('Credential saved successfully!', 'success');
            }

            this.clearSetupForm();
            await this.refreshProgramDropdown();
        } catch (error) {
            console.error('Error saving credential:', error);
            this.showToast('Error saving credential: ' + error.message, 'danger');
        }
    },

    // Save and close modal
    async saveAndClose() {
        await this.saveCredential();
        const modal = bootstrap.Modal.getInstance(document.getElementById('credentialSetupModal'));
        modal.hide();
    },

    // View all credentials
    async viewCredentials() {
        const credentials = await CredentialManager.getAll();
        const tbody = document.getElementById('viewCredsTableBody');
        tbody.innerHTML = '';

        if (credentials.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-muted">
                        <i class="bi bi-inbox"></i> No credentials saved yet
                    </td>
                </tr>
            `;
        } else {
            credentials.forEach(cred => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${this.escapeHtml(cred.Program)}</td>
                    <td>${this.escapeHtml(cred.DomainControllerIP)}</td>
                    <td>${this.escapeHtml(cred.DomainUsername)}</td>
                    <td>${cred.DomainPassword ? '••••••••' : '<span class="text-muted">Not set</span>'}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="CredentialUI.editCredential(${cred.id})">
                            <i class="bi bi-pencil"></i> Edit
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-outline-danger" onclick="CredentialUI.deleteCredential(${cred.id}, '${this.escapeHtml(cred.Program)}')">
                            <i class="bi bi-trash"></i> Delete
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        const modal = new bootstrap.Modal(document.getElementById('viewCredentialsModal'));
        modal.show();
    },

    // Edit credential
    async editCredential(id) {
        const credentials = await CredentialManager.getAll();
        const credential = credentials.find(c => c.id === id);

        if (!credential) {
            this.showToast('Credential not found', 'danger');
            return;
        }

        // Close view modal
        const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewCredentialsModal'));
        if (viewModal) viewModal.hide();

        // Open edit modal
        this.currentEditId = id;
        document.getElementById('setupProgram').value = credential.Program;
        document.getElementById('setupDCIP').value = credential.DomainControllerIP;
        document.getElementById('setupUsername').value = credential.DomainUsername;
        document.getElementById('setupPassword').value = credential.DomainPassword || '';
        document.getElementById('setupModalTitle').textContent = 'Edit Credential';
        document.getElementById('setupInstructions').style.display = 'none';

        const setupModal = new bootstrap.Modal(document.getElementById('credentialSetupModal'));
        setupModal.show();
    },

    // Delete credential
    async deleteCredential(id, programName) {
        if (!confirm(`Are you sure you want to delete the credential for "${programName}"?`)) {
            return;
        }

        try {
            await CredentialManager.delete(id);
            this.showToast('Credential deleted successfully!', 'success');
            await this.viewCredentials(); // Refresh the view
            await this.refreshProgramDropdown();
        } catch (error) {
            console.error('Error deleting credential:', error);
            this.showToast('Error deleting credential: ' + error.message, 'danger');
        }
    },

    // Clear all credentials with confirmation
    async clearAllCredentials() {
        if (!confirm('⚠️ WARNING: This will delete ALL saved credentials. Are you sure?')) {
            return;
        }

        if (!confirm('This action cannot be undone. Continue?')) {
            return;
        }

        try {
            await CredentialManager.clearAll();
            this.showToast('All credentials cleared successfully!', 'warning');
            await this.refreshProgramDropdown();
            
            // Show initial setup modal again
            setTimeout(() => {
                this.showInitialSetupModal();
            }, 500);
        } catch (error) {
            console.error('Error clearing credentials:', error);
            this.showToast('Error clearing credentials: ' + error.message, 'danger');
        }
    },

    // Refresh program dropdown
    async refreshProgramDropdown() {
        const dropdown = document.getElementById('programDropdown');
        const credentials = await CredentialManager.getAll();

        // Clear existing options except the first one
        dropdown.innerHTML = '<option selected value="">-- Select a Program --</option>';

        credentials.forEach(cred => {
            const option = document.createElement('option');
            option.value = cred.id;
            option.textContent = cred.Program;
            option.dataset.dcip = cred.DomainControllerIP;
            option.dataset.username = cred.DomainUsername;
            option.dataset.password = cred.DomainPassword || '';
            dropdown.appendChild(option);
        });
    },

    // Handle program dropdown selection change
    handleProgramSelection() {
        const dropdown = document.getElementById('programDropdown');
        const selectedOption = dropdown.options[dropdown.selectedIndex];
        
        // Get input fields
        const dcIPInput = document.getElementById('dcIP');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const ntAccountInput = document.getElementById('ntAccount');

        if (selectedOption.value === '') {
            // Default option selected - clear fields
            dcIPInput.value = '';
            usernameInput.value = '';
            passwordInput.value = '';
            return;
        }

        // Populate fields from selected option's data attributes
        dcIPInput.value = selectedOption.dataset.dcip || '';
        passwordInput.value = selectedOption.dataset.password || '';
        
        // Build username as: DomainUsername\NTAccount
        const domainUsername = selectedOption.dataset.username || '';
        const ntAccount = ntAccountInput.value.trim();
        
        if (ntAccount) {
            usernameInput.value = `${domainUsername}\\${ntAccount}`;
        } else {
            // If NT Account is empty, just show the domain username
            usernameInput.value = domainUsername;
        }

        console.log('Program selected:', {
            program: selectedOption.textContent,
            dcIP: dcIPInput.value,
            domainUsername: domainUsername,
            ntAccount: ntAccount,
            fullUsername: usernameInput.value,
            hasPassword: !!passwordInput.value
        });
    },

    // Update username when NT Account changes
    handleNTAccountChange() {
        const ntAccountInput = document.getElementById('ntAccount');
        const usernameInput = document.getElementById('username');
        const dropdown = document.getElementById('programDropdown');
        const selectedOption = dropdown.options[dropdown.selectedIndex];
        
        // Only update if a program is selected
        if (selectedOption.value === '') {
            usernameInput.value = '';
            return;
        }
        
        const domainUsername = selectedOption.dataset.username || '';
        const ntAccount = ntAccountInput.value.trim();
        
        if (ntAccount) {
            usernameInput.value = `${domainUsername}\\${ntAccount}`;
        } else {
            usernameInput.value = domainUsername;
        }

        console.log('NT Account updated:', {
            domainUsername: domainUsername,
            ntAccount: ntAccount,
            fullUsername: usernameInput.value
        });
    },

    // Show toast notification
    showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toastContainer');
        const toastId = 'toast_' + Date.now();
        
        const toastHtml = `
            <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        `;
        
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
        toast.show();

        // Remove toast element after it's hidden
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    },

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
};

// ============================================================================
// INITIALIZATION
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Initialize IndexedDB
        await CredentialManager.init();

        // Check if credentials exist
        const hasCredentials = await CredentialManager.hasCredentials();

        if (!hasCredentials) {
            // No credentials - show initial setup modal with template data
            console.log('No credentials found. Showing initial setup modal...');
            
            // If credentialsData from creds.js exists, use it as template
            if (typeof credentialsData !== 'undefined' && credentialsData.length > 0) {
                console.log('Using creds.js as template');
                // Optionally pre-populate with template (commented out by default)
                // await CredentialManager.initializeFromTemplate(credentialsData);
            }
            
            CredentialUI.showInitialSetupModal();
        } else {
            // Credentials exist - load into dropdown
            console.log('Credentials found. Loading into dropdown...');
            await CredentialUI.refreshProgramDropdown();
        }

        // ========================================================================
        // CRITICAL: Setup program dropdown change event listener
        // ========================================================================
        const programDropdown = document.getElementById('programDropdown');
        if (programDropdown) {
            programDropdown.addEventListener('change', () => {
                CredentialUI.handleProgramSelection();
            });
            console.log('Program dropdown change listener attached');
        } else {
            console.error('Program dropdown element not found!');
        }

        // ========================================================================
        // CRITICAL: Setup NT Account input change event listener
        // ========================================================================
        const ntAccountInput = document.getElementById('ntAccount');
        if (ntAccountInput) {
            // Enable program dropdown when NT Account has value
            ntAccountInput.addEventListener('input', () => {
                const dropdown = document.getElementById('programDropdown');
                if (ntAccountInput.value.trim()) {
                    dropdown.disabled = false;
                } else {
                    dropdown.disabled = true;
                }
                
                // Update username field when NT Account changes
                CredentialUI.handleNTAccountChange();
            });
            console.log('NT Account input listener attached');
        } else {
            console.error('NT Account input element not found!');
        }

        // Setup gear icon event listeners
        document.getElementById('addCredentialBtn').addEventListener('click', () => {
            CredentialUI.showAddCredentialModal();
        });

        document.getElementById('viewCredentialsBtn').addEventListener('click', () => {
            CredentialUI.viewCredentials();
        });

        document.getElementById('clearAllCredentialsBtn').addEventListener('click', () => {
            CredentialUI.clearAllCredentials();
        });

        // Setup modal save buttons
        document.getElementById('saveCredentialBtn').addEventListener('click', () => {
            CredentialUI.saveCredential();
        });

        document.getElementById('saveAndCloseBtn').addEventListener('click', () => {
            CredentialUI.saveAndClose();
        });

    } catch (error) {
        console.error('Error initializing credential manager:', error);
        alert('Error initializing credential storage: ' + error.message);
    }
});