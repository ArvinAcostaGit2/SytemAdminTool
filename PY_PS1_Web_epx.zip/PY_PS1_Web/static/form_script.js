// ============================================================================
// FORM UTILITY FUNCTIONS
// Helper functions for form management (non-credential related)
// ============================================================================

// Clear all fields
function clearAllFields() {
    document.getElementById('searchNames').value = '';
    document.getElementById('ntAccount').value = '';
    document.getElementById('dcIP').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('programDropdown').value = '';
    document.getElementById('programDropdown').disabled = true;
    
    // Hide results section if visible
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('errorAlert').style.display = 'none';
}

// Toggle Domain Password Visibility
function toggleDomainPasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('toggleDomainPasswordIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('bi-eye');
        toggleIcon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('bi-eye-slash');
        toggleIcon.classList.add('bi-eye');
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Clear All button
    const clearAllBtn = document.getElementById('clearAllBtn');
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to clear all fields? This will reset the form.')) {
                clearAllFields();
            }
        });
    }

    // Toggle Domain Password visibility
    const toggleDomainPasswordBtn = document.getElementById('toggleDomainPasswordBtn');
    if (toggleDomainPasswordBtn) {
        toggleDomainPasswordBtn.addEventListener('click', toggleDomainPasswordVisibility);
    }

    console.log('Form script initialized - credential management handled by creds_manager.js');
});