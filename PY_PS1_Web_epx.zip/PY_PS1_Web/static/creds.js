        const credentialsData = [
            {
                "Program": "Core",
                "DomainControllerIP": "10.16.64.16",
                "DomainUsername": "",
                "DomainPassword": ""
            }
        ];