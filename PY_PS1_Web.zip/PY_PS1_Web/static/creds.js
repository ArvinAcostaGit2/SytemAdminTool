        const credentialsData = [
            {
                "Program": "Core",
                "DomainControllerIP": "10.16.64.16",
                "DomainUsername": "EPX",
                "DomainPassword": ""
            },
            {
                "Program": "Core Admin",
                "DomainControllerIP": "10.16.64.16",
                "DomainUsername": "EPX",
                "DomainPassword": ""
            },
            {
                "Program": "Core2",
                "DomainControllerIP": "10.16.64.16",
                "DomainUsername": "EPX",
                "DomainPassword": ""
            },
            {
                "Program": "Demo Domain3",
                "DomainControllerIP": "10.16.80.16",
                "DomainUsername": "SPRINT\\demo_user",
                "DomainPassword": "password123"
            },
            {
                "Program": "Demo Domain4",
                "DomainControllerIP": "10.16.92.16",
                "DomainUsername": "SHOPEE\\demo_user",
                "DomainPassword": ""
            }
        ];